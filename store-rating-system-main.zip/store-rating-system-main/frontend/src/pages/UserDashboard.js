import React from 'react';
import { Typography } from '@mui/material';

export default function UserDashboard() {
  return (
    <>
      <Typography variant="h5">User Dashboard</Typography>
      <Typography>Here you can browse stores and submit ratings.</Typography>
      
    </>
  );
}
